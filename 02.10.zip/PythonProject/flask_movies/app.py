from flask import Flask, render_template

app = Flask(__name__)

movies = [
    {
        "id": 1,
        "title": "Интерстеллар",
        "year": 2014,
        "rating": 8.7,
        "genre": "Фантастика",
        "description": "Группа исследователей отправляется через червоточину в космосе в поисках нового дома для человечества."
    },
    {
        "id": 2,
        "title": "Матрица",
        "year": 1999,
        "rating": 8.5,
        "genre": "Боевик, фантастика",
        "description": "Хакер узнаёт, что реальный мир — это симуляция, созданная машинами."
    },
    {
        "id": 3,
        "title": "Шрек",
        "year": 2001,
        "rating": 8.1,
        "genre": "Мультфильм, комедия",
        "description": "Зелёный огр отправляется спасать принцессу, чтобы вернуть своё болото."
    },
    {
        "id": 4,
        "title": "Начало",
        "year": 2010,
        "rating": 8.8,
        "genre": "Фантастика, триллер",
        "description": "Вор проникает в сны людей, чтобы украсть их секреты."
    },
    {
        "id": 5,
        "title": "Форрест Гамп",
        "year": 1994,
        "rating": 8.6,
        "genre": "Драма, мелодрама",
        "description": "История жизни простого человека с большим сердцем."
    }
]

@app.route("/")
def index():
    return render_template("index.html", movies=movies)

@app.route("/movie/<int:movie_id>")
def movie(movie_id):
    for m in movies:
        if m["id"] == movie_id:
            return render_template("movie.html", movie=m)
    return "Фильм не найден", 404

if __name__ == "__main__":
    app.run(debug=True)