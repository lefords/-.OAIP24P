from flask import Flask, render_template, redirect, session
import random

app = Flask(__name__)
# Секретный ключ ОБЯЗАТЕЛЕН для работы сессий
app.secret_key = "super-secret-key-123"

# Список фильмов с добавлением genre и rating (Самостоятельная часть)
movies = [
    {"id": 1, "title": "Интерстеллар", "year": 2014, "genre": "Фантастика", "rating": 8.7},
    {"id": 2, "title": "Матрица", "year": 1999, "genre": "Боевик, фантастика", "rating": 8.5},
    {"id": 3, "title": "Шрек", "year": 2001, "genre": "Мультфильм, комедия", "rating": 8.1},
    {"id": 4, "title": "Джентльмены", "year": 2019, "genre": "Криминал, комедия", "rating": 8.5}
]


@app.route("/")
def index():
    favorites = session.get("favorites", [])
    return render_template("index.html", movies=movies, favorites_count=len(favorites))


@app.route("/add/<int:movie_id>")
def add_favorite(movie_id):
    if "favorites" not in session:
        session["favorites"] = []

    # Проверка на дубликаты (Самостоятельная часть)
    if movie_id not in session["favorites"]:
        session["favorites"].append(movie_id)

    return redirect("/")


@app.route("/favorites")
def favorites():
    favorite_ids = session.get("favorites", [])
    # Фильтруем список фильмов, оставляя только избранные
    favorite_movies = [movie for movie in movies if movie["id"] in favorite_ids]
    return render_template("favorites.html", movies=favorite_movies)


@app.route("/remove/<int:movie_id>")
def remove_favorite(movie_id):
    if "favorites" in session and movie_id in session["favorites"]:
        session["favorites"].remove(movie_id)
    return redirect("/favorites")


@app.route("/clear")
def clear_favorites():
    session["favorites"] = []
    return redirect("/favorites")


# Дополнительное задание: случайный фильм
@app.route("/random")
def random_movie():
    movie = random.choice(movies)
    return render_template("random.html", movie=movie)


if __name__ == "__main__":
    app.run(debug=True)