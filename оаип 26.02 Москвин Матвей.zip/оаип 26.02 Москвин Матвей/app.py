from flask import Flask, render_template

app = Flask(__name__)

# Задание 1
@app.route('/<float:num>/')
def double_number(num):
    doubled = num * 2
    text = f"Ваше число {num}, умноженное на 2: {doubled}"
    return render_template('index.html', number=doubled, text=text)

# Задание 2
@app.route('/circle/<float:r>/')
def circle_area(r):
    pi = 3.14
    area = pi * r * r
    return render_template('index.html', r=r, pi=pi, area=area)

if __name__ == '__main__':
    app.run(debug=True)
    #Для проверки открывать эти ссылки
    #Задание 1: http://127.0.0.1:5000/2.5/
    #Задание 2: http://127.0.0.1:5000/circle/2.34/