from flask import Flask, render_template

app = Flask(__name__)

@app.route('/median')
def median():
    a, b, c = 1, 3, 2
    return render_template('index1.html', a=a, b=b, c=c)

if __name__ == '__main__':
    app.run(debug=True)
#Для проверки http://localhost:5000/median