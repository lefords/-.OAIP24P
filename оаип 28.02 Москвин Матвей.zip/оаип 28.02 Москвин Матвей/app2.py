from flask import Flask, render_template

app = Flask(__name__)

@app.route('/<path:expr>/')
def calc(expr):
    parts = expr.strip('/').split('/')
    if len(parts) != 3:
        return "Ошибка"
    try:
        a = float(parts[0])
        op = parts[1]
        b = float(parts[2])
    except Exception:
        return "Ошибка"
    return render_template('index2.html', a=a, op=op, b=b)

if __name__ == '__main__':
    app.run(debug=True)
#Для проверки http://localhost:5000/7/*/2/