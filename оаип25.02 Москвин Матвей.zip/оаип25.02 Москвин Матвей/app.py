from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

LOGIN = "admin"
PASSWORD = "1234"

@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        user_login = request.form.get("login")
        user_password = request.form.get("password")
        
        if user_login == LOGIN and user_password == PASSWORD:
            return redirect(url_for("me"))
        else:
            return render_template("login.html", error="Неверный логин или пароль!")
    
    return render_template("login.html")

@app.route("/me")
def me():
    return render_template("index.html", name="Матвей Москвин")  

@app.route("/about")
def about():
    return render_template("about.html")

if __name__ == "__main__":
    app.run(debug=True)